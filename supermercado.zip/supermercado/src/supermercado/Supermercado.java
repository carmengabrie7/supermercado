/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermercado;

import java.util.Scanner;


/**
 *
 * @author Carmen
 */
public class Supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int cantidad;
        double costo, costototal=0;
        
        System.out.println("Bienvenido a tu Supermercado Virtual! 🛒");
        
        System.out.println("Ingrese la cantidad de productos a registrar: ");
        cantidad=entrada.nextInt();
        
        for (int i = 1; i <= cantidad; i++){
            System.out.print("Ingrese el costo del producto " + i + ": ");
            costo = entrada.nextDouble();
            
            System.out.print("Ingrese la cantidad del producto " + i + ": ");
            int numProductos = entrada.nextInt();
            
            
            costototal += costo * numProductos;
        }
        
        System.out.printf("El costo total de la compra es: "+costototal);
        
        entrada.close();
    }
}

